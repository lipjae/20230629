import { defineStore } from 'pinia'
import { app } from 'boot/firebase'
import { getDatabase, ref, onValue} from "firebase/database"

export const useMapStore = defineStore('map', {
  state: () => ({
    mapData: []
  }),
  getters: {
    
  },
  actions: {

    loadMapData() {
      console.log('loadMapData')
      const db = getDatabase(app)
      const mapRef = ref(db, '/map')
      onValue(mapRef, (snapshot) => {
        const data = snapshot.val()
        this.mapData = data
      })
    }

  },
})

<template>
  <q-page class="row">
    <div class="table-wrap">
      <q-table
        title="약국리스트"
        :rows="mapData"
        :columns="columns"
        row-key="name"
        :pagination="pagination"
      />
    </div>
    <div class="map-wrap">
      <div id="map"></div>
    </div>
  </q-page>
</template>

<script>
import { defineComponent } from 'vue'
const columns = [
  {
    name: 'name',
    required: true,
    label: '약국명',
    align: 'left',
    field: row => row.name,
    format: val => `${val}`,
  },
  { name: 'addr', align: 'left', label: '주소', field: 'addr' },
  { name: 'open', label: '운영시간', field: 'open' },
  { name: 'likeCount', label:'좋아요',field: 'likeCount'}
]

import { useMapStore } from 'src/stores/map'
import { storeToRefs } from 'pinia'
import { useMap } from 'src/composable/map'

export default defineComponent({
  name: 'IndexPage',
  setup() {

    const $map = useMapStore()

    $map.loadMapData()

    const { mapData } = storeToRefs($map)

    const { pagination } = useMap()
    
    return {
      columns,
      mapData,
      pagination,
    }
  }
})
</script>
<style lang="scss" scoped>
.table-wrap {
  width: 40vw;
}
.map-wrap {
  flex: 1;
  #map { width: 100%; height: 100vh;}
}
</style>
